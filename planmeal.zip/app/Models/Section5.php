<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section5 extends Model{
    protected $table = 'meal_section5';
    protected $fillable = [
        'video','sec5_status'
    ];
    
    
}
