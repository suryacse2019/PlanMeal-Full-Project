<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section8 extends Model{
    protected $table = 'meal_section8';
    protected $fillable = [
       'sec8_status'
    ];
    
    
}
