<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BestToEat extends Model
{
    protected $table = 'Best_to_eat';
    protected $fillable = [
        'name'
    ];
}
