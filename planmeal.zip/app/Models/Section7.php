<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section7 extends Model{
    protected $table = 'meal_section7';
    protected $fillable = [
        'heading1','heading2','banner','sec7_status'
    ];
    
    
}
