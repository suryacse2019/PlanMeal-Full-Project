<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section4 extends Model{
    protected $table = 'meal_section4';
    protected $fillable = [
        'heading1','heading2','sec4_status'
    ];
    
    
}
